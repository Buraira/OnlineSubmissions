#include <stdio.h>

int main()
{
	unsigned int i, j, n, cycle, max,  ti, tj;

	cycle = 1;
	max = 0;

	while (scanf("\n%d %d",&i,&j) != EOF)
	{

		ti = i;
		tj = j;

            if (i > j)
            {
                long int temp = i;
                i=j;
                j=temp;
            }

            for(; i <= j; i++)
            {
                n=i;
                while(n != 1 )
                {
                    if ((n%2) == 1)
                        n = (3*n)+1;
                    else
                        n = n/2;
                    cycle++;
                }
                if(cycle > max)
                {
                    max = cycle;
                }
                cycle=1;
            }

		printf("%d %d %d\n", ti,tj,max);
		max = 0;
		}

	return 0;
}
